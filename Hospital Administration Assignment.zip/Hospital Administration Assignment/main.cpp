#include <iostream>

int main() {

}
